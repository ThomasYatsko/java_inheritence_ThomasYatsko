package csci3444.inheritence;

public interface Student extends Person
{
	public String studiesFor();
}
