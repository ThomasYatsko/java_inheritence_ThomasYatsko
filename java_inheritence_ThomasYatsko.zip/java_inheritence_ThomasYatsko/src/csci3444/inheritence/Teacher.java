package csci3444.inheritence;

public interface Teacher extends Person
{
	public String teachesFor();
}
