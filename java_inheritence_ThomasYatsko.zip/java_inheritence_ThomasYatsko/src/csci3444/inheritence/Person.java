package csci3444.inheritence;

public interface Person 
{
	public String getName();
	public String getDetails();
}
