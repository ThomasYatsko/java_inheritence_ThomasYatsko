/**
 * 
 */
/**
 * @author thoma
 *
 */
package csci3444.inheritence;