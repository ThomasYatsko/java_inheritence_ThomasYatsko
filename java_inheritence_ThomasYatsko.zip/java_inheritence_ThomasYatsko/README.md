create interfaces (Person, Studying, Teaching),

create abstract base class that contain some common attribute and methods of classes that implement an interface (PersonBase),

create multiple implementation classes of an interface (Professor, Student),

a class implementing multiple interfaces (Student, Professor),

polymorphism, users of implementations of an interface to view them via interface (MainEntryClass.main),

